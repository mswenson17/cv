function doAll()
    computeDictionary()
    batchToVisualWords(3)
    buildRecognitionSystem()
    evaluateRecognitionSystem()

end

